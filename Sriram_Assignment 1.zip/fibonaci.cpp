#include<iostream>
#include<chrono> 

using namespace std;
using namespace std::chrono;

int fibonnaci(int n){
	if(n <= 1){
		return n;
	}
	else return fibonnaci(n-1) + fibonnaci(n-2);
}

int main(){
	auto start = high_resolution_clock::now(); 
	cout << fibonnaci(35) << endl; 
	auto stop = high_resolution_clock::now();
       auto duration = duration_cast<microseconds>(stop - start); 
	cout << duration.count() << endl;        
}
