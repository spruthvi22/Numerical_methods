import time


def fibonnaci(n): 
    if n <= 1: 
        return n
    else: 
        return fibonnaci(n-1) + fibonnaci(n-2) 

start = time.time()
print(fibonnaci(35))
end = time.time() 
print(end - start)
