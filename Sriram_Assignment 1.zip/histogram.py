import numpy as np 
import matplotlib.pyplot as plt 

a = np.random.rand(1000) 
b = np.random.normal(loc = 0, scale = 1, size = 1000)

plt.subplot(1,2,1)
plt.hist(a)
plt.title("Random Number Histogram")
plt.xlabel("Random Numbers")
plt.ylabel("Frequency")


plt.subplot(1,2,2) 
plt.hist(b, range = (-2,2))
plt.title("Normal Distribution Histogram")
plt.xlabel("Normally distributed numbers")

plt.suptitle("Histograms on Matplotlib") 
plt.show()

