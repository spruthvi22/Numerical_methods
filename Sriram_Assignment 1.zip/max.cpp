#include <iostream> 

using namespace std; 

int main(){
       int n;  	
	cout << "Enter number of elements in your array: "; 
	cin >> n;
       int arr[n]; 	
       cout << "Enter an array with chosen number of elements: "; 
	for(int i = 0; i < n; i++){ 
	 cin >> arr[i];
	}
	int max = 0;
	
	for(int i = 0; i < n; i++){
		if(max < arr[i]){
			max = arr[i];
		}
	}
	cout << "The maximum of your array is: " << max << endl; 
}	

