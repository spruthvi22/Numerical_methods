def maximum(list1): 
    for i in range(len(list1)):
        max = 0 
        if list1[i] > max:
            max = list1[i]

    return max




