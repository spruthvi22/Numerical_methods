#include<iostream> 
using namespace std; 

int main(){ 
	int n, m; 
	cout << "Enter number of elements in your array: " << endl; 
	cin >> n; 
	cout << "Enter an array with chosen number of elements: " << endl; 
	int arr[n]; int i; int j;	
	for(i=0; i<n; i++){
		cin >> arr[i]; 
	}
	cout << "Enter number of maximum elements needed: " << endl; 
	cin >> m; 
	int brr[m]; int x; 
	       for(j=0;j<m;j++){
		       x = 0; 
		       for(i = 0; i < n; i++){ 
			       if(x < arr[i]){
				       x = arr[i];
			       }
		       }
		       brr[j] = x; 
		       for(i = 0; i < n; i++){
			       if(arr[i] == x){
				       arr[i] = -1;
			       }
		       }
	       }
	int k=0; 
	while (k < m) { 
		cout << brr[k] << endl;  
		k++;
	}
}

 	

