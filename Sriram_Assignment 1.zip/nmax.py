def nmax(list1, n): 
    list2 = [] 
    for i in range(0, n): 
        max1 = 0

        for j in range(len(list1)):
            if list1[j] > max1:
                max1 = list1[j]; 

        list1.remove(max1); list2.append(max1) 

    return list2 

array = [1, 2, 3, 4, 5, 6, 10, 14, 7, 100] 
print(nmax(array, 3))

